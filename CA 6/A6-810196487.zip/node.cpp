#include <iostream>
#include <vector>
#include "node.hpp"

using namespace std;

void Node::addNode(Node* newNode){
	nodesOfNode.push_back(newNode);
}