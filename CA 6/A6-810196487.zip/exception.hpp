#ifndef __Exceptions_H__
#define __Exceptions_H__

#include <iostream>
#include <string>

class Exceptions{
	public:
		virtual void what() = 0 ;
};

class RepeatedID : public Exceptions{
	cerr << "Duplicate nide ID.";
}

class FatherDoesNotExist : public Exceptions{
public:
	virtual void what() {
		cerr << "Parent node not found.";
	}

};

class OperandIsFather :public Exceptions{
public:
	virtual void what() {
		cerr << "Invalid parent.";
	}
};

class ChildrenOfRouteWithDifferentTypes :public Exceptions{
public:
	virtual void what() {
		cerr << "Invalid parent.";
	}
};

class BadTreeStructure :public Exceptions{
public:
	virtual void what() {
		cerr << "Invalid tree structure.";
	}
};

#endif