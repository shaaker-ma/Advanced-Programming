#ifndef __Multiply_H__
#define __Multiply_H__

#include "operand.hpp";

class MultiplyNode : public Operator{
	public:
		MultiplyNode(const std::size_t id, const std::size_t parent_id) Operator(id,parent_id) {}
		int evaluate(){ 
				int multResult = 1; 
				if(nodesOfOneNode.size() != 2){
					Exception* excp;
					excp = new BadTreeStructure();
					throw excp;
				}
				for(int i=0; i<nodesOfNode.size() ;i++){
					multResult = multResult * nodesOfNode[i]->evaluate();
				}
				return multResult;
		}
};

#endif
