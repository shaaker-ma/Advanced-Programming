#ifndef __OPERAND_H__
#define __OPERAND_H__

class Operand : public Node{
	public:
		int evaluate(){ return value;}
	private:
		int value;
}

#endif