#ifndef __OPERATOR_H__
#define __OPERATOR_H__

#include "exception.hpp"

class Operator : public Node {
	public:
		Operator(const std::size_t id, const std::size_t parent_id) Node(id,parent_id) {}
		virtual int evaluate(); 
}

class AddNode : public Operator{
	public:
		AddNode(const std::size_t id, const std::size_t parent_id) Operator(id,parent_id) {}
		int evaluate(){ 
				if(nodesOfOneNode.size() != 2){
					Exception* excp;
					excp = new BadTreeStructure();
					throw excp;
				}
				return (*nodesOfOneNode[0])+(*nodesOfOneNode[1]);
		}
}

class MultiplyNode : public Operator{
	public:
		int evaluate(){ 
				if(nodesOfOneNode.size() != 2){
					Exception* excp;
					excp = new BadTreeStructure();
					throw excp;
				}
				return (*nodesOfOneNode[0])*(*nodesOfOneNode[1]);
		}
}

class NotNode : public Operator{
	public:
		int evaluate(){ 
			if(nodesOfOneNode.size() != 1){
					Exception* excp;
					excp = new BadTreeStructure();
					throw excp;
				}
				return -(*nodesOfOneNode[0]);
		}
}

class MedianNode : public Operator{
	public:
		int evaluate(){ 
			int numfOfElements = nodesOfOneNode.size();
			if(numfOfElements % 2 == 0){
				
			}
		}
}

#endif