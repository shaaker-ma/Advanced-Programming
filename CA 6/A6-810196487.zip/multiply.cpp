#ifndef __ADD_H__
#define __ADD_H__

class Multiply : public Operator{
	public:
		int evaluate(){ return value;}
	private:
		int value;
}

#endif