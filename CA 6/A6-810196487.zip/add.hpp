#ifndef __ADD_H__
#define __ADD_H__

#include "operand.hpp";

class AddNode : public Operator{
	public:
		AddNode(const std::size_t id, const std::size_t parent_id) Operator(id,parent_id) {}
		int evaluate(){
				int addResult = 0; 
				if(nodesOfOneNode.size() != 2){
					Exception* excp;
					excp = new BadTreeStructure();
					throw excp;
				}
				for(int i=0; i<nodesOfNode.size() ;i++){
					addResult = addResult + nodesOfNode[i]->evaluate();
				}
				return addResult;
		}
};

#endif
