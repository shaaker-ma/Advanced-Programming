#ifndef __Median_H__
#define __Median_H__

#include "operand.hpp";

class MedianNode : public Operator{
	public:
		MedianNode(const std::size_t id, const std::size_t parent_id) Operator(id,parent_id) {}
		int evaluate(){ 
			int medesult =0;
			int numfOfElements = nodesOfOneNode.size();
			//must not change and sort first
			vector<int> sortedNodeValue;
			for(int i=0; i<nodesOfNode.size() ;i++){
				sortedNodeValue.push_back(nodesOfNode[i]->evaluate());
			}
			sort(sortedNodeValue.begin() , sortedNodeValue.end());
			//now we say if %2 =0 => zooj
			//now we say if %2 !=0 => fard
			if(numfOfElements % 2 == 0){
				medesult = (sortedNodeValue[(numfOfElements/2)-1] + sortedNodeValue[(numfOfElements/2)])/2;
			}
			else{
				medesult = sortedNodeValue[(numfOfElements/2)];
			}
			return medesult;
		}
};

#endif
