#ifndef __Not_H__
#define __Not_H__

#include "operand.hpp";

class NotNode : public Operator{
	public:
		NotNode(const std::size_t id, const std::size_t parent_id) Operator(id,parent_id) {}
		int evaluate(){ 
			if(nodesOfOneNode.size() != 1){
					Exception* excp;
					excp = new BadTreeStructure();
					throw excp;
				}
				return (-1)*(nodesOfNode[0]->value);
		}
};

#endif
