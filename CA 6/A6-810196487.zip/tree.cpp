#include "tree.hpp"
#include "node.hpp"

void Tree::add_operand_node(const std::size_t id, const std::size_t parent_id, const int value){
	
	//check if father exists
	//check if operand is father
	//check if


	Node* newNode = new Operand(id,parent_id,value);
	allNodes.push_back(newNode);
	
}

void Tree::add_operator_node(const std::size_t id, const std::size_t parent_id, const OperatorType type){
	Add, Multiply, Not, Median
	if(type == Add){
		Node* newNode = new Operator(id,parent_id,type);
		allNodes.push_back(newNode);
	}
	else if(type == Multiply){
		Node* newNode = new Operator(id,parent_id,type);
		allNodes.push_back(newNode);
	}
	else if(type == Not){
		Node* newNode = new Operator(id,parent_id,type);
		allNodes.push_back(newNode);
	}
	else if(type == Median){
		Node* newNode = new Operator(id,parent_id,type);
		allNodes.push_back(newNode);
	}
}

int Tree::evaluate_tree(){
	Node::evaluate(allNodes);
}