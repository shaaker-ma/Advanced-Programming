#ifndef __NODE_H__
#define __NODE_H__

#include <vector>
using namespace std;

class Node{
public:
	Node(const std::size_t id, const std::size_t parent_id){
		idOfNode = id;
		parent_idOfNode = parent_id;
	}
	void addNode(Node* newNode);
	//Node* findNode()
	virtual int evaluate() = 0;
protected:
	std::size_t idOfNode;
	std::size_t	parent_idOfNode;
	vector <Node*> nodesOfNode;
};
#endif